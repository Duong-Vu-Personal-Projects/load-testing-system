package com.vn.ptit.duongvct.dto.request.testrun;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RequestTestRunDTO {
    private String id;
}
