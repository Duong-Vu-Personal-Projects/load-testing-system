package com.vn.ptit.duongvct.dto.response.testplan;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
public class ResponseTableTestPlanDTO {
    private String id;
    private String title;
}
