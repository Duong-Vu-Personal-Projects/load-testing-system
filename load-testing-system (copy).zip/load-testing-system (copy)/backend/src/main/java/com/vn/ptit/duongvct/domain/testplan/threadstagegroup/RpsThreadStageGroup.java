package com.vn.ptit.duongvct.domain.testplan.threadstagegroup;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RpsThreadStageGroup extends BaseThreadGroup{
    private int maxThreads;
}
