package com.vn.ptit.duongvct.domain.testplan.threadstagegroup;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ThreadStageGroup extends BaseThreadGroup{
    protected int holdIteration;

}
