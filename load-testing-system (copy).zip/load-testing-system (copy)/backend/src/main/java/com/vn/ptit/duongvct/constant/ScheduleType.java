package com.vn.ptit.duongvct.constant;

public enum ScheduleType {
    ONCE,      // Run once at a specific time
    RECURRING  // Run repeatedly according to a cron schedule
}