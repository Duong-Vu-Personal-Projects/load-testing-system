package com.vn.ptit.duongvct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadTestingApplicationTests {

	@Test
	void contextLoads() {
	}

}
