const AdminDashboard = () => {
    return (
        <>
            Admin Page
        </>
    )
}
export default AdminDashboard;